/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 04/04/2024 - 12:56:18
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 04/04/2024
 * - Author          : admin
 * - Modification    :
 **/
import Login from "./components/User/Login";
import Register from "./components/User/Register";
import { Routes, Route } from "react-router-dom";
import ProtectedRoute from "./Routes/ProtectedRoute";
import Account from "./components/Admin/Account";
import NotFound from "./components/NotFound";
import Dashboard from "./components/Admin/Dashboard";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute isAdmin={true}>
            <Dashboard activeTab={0}>
            </Dashboard>
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/account"
          element={
             <ProtectedRoute isAdmin={true}>
            <Dashboard activeTab={5}>
              <Account />
            </Dashboard>
             </ProtectedRoute>
          }
        ></Route>
        <Route path="*" element={<NotFound />}></Route>
      </Routes>
    </>
  );
}

export default App;
