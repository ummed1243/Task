/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 04/04/2024 - 14:32:42
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 04/04/2024
 * - Author          : admin
 * - Modification    :
 **/
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import EqualizerIcon from "@mui/icons-material/Equalizer";
import LogoutIcon from "@mui/icons-material/Logout";
import AccountBoxIcon from "@mui/icons-material/AccountBox";
import CloseIcon from "@mui/icons-material/Close";
import { useDispatch } from "react-redux";
import "./Sidebar.css";
import { useSnackbar } from "notistack";
import { logoutUser } from "../../../actions/userAction";
import { useTheme } from "@mui/material/styles";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const navMenu = [
  {
    icon: <EqualizerIcon />,
    label: "Dashboard",
    ref: "/admin/dashboard",
    submenu: []
  },
  {
    icon: <AccountBoxIcon />,
    label: "Profile",
    ref: "/account",
    submenu: []
  },
  {
    icon: <LogoutIcon />,
    label: "Logout",
    submenu: []
  }
];


const Sidebar = ({ activeTab, setToggleSidebar }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const [showSubMenu, setShowSubMenu] = useState(true);

  const handleLogout = () => {
    dispatch(logoutUser());
    enqueueSnackbar("Logout Successfully", { variant: "success" });
    navigate("/");
  };


  return (
    <aside className="mt-15 sidebar z-10 sm:z-0 block min-h-screen fixed left-0 pb-14 max-h-screen w-3/4 sm:w-1/6 bg-gray-800 text-white-sidebar overflow-x-hidden border-r">
      <div className="flex flex-col w-full gap-0 my-8">
      <button onClick={()=>setToggleSidebar(false)} className="sm:hidden bg-gray-800 ml-auto rounded-full w-10 h-10 flex items-center justify-center">
                    <CloseIcon/>
                </button>
        {navMenu.map((item, index) => {
          const { icon, label, ref, submenu } = item;
          return (
            <div className="relative" key={index}>
              {label === "Logout" ? (
                <Link
                  onClick={handleLogout}
                  className="hover:bg-gray-700 flex gap-3 items-center py-3 px-4 font-medium"
                >
                  <span>{icon}</span>
                  <span>{label}</span>
                </Link>
              ) : (
                <Link
                  to={ref}
                  onClick={() => {
                    setShowSubMenu(prevShowSubMenu =>
                      activeTab === index ? !prevShowSubMenu : prevShowSubMenu
                    );
                  }}                
                  className={`${
                    activeTab === index ? "bg-gray-701" : "hover:bg-gray-700"
                  } flex gap-3 items-center py-3 px-4 font-medium`}
                >
                  <span>{icon}</span>
                  <span className="set-icons-side">{label} {submenu.length >0 ? <ExpandMoreIcon /> : ''}</span>
                </Link>
               )} 
              {submenu.length >0 && activeTab === index && showSubMenu && (
                <div className="left-0 mt-2 w-100 bg-white rounded-0 border-bottom-1 shadow-lg bg-gray-701 gap-3 font-medium">
                  {submenu.map((subItem, subIndex) => (
                    <Link
                      key={subIndex}
                      to={subItem.ref}
                      className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
                    >
                      {subItem.label}
                    </Link>
                  ))}
                  
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
};

export default Sidebar;
