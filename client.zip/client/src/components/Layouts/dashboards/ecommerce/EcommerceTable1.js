/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 09/04/2024 - 18:43:50
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 09/04/2024
 * - Author          : admin
 * - Modification    :
 **/
// ** MUI Imports
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { DataGrid } from "@mui/x-data-grid";
import CustomChip from "../../../../@core/components/mui/chip";
import CardHeader from "@mui/material/CardHeader";
import { styled } from '@mui/material/styles';

const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-columnHeader': {
    backgroundColor: '#f5f5f7' // Set your desired background color here
  }
}));

const statusObj = {
  active: { color: "success" },
  pending: { color: "warning" },
  inactive: { color: "secondary" }
};

const rows = [
  {
    id: 1,
    status: "pending",
    plateform: "Woocommerce",
    store: "Store A",
    orderId: "2548",
    email: "john123@gmail.com",
    product: "5",
    amount: "450",
    qty: "6",
    time: "6:20 AM"
  },
  {
    id: 2,
    status: "active",
    plateform: "Shopify",
    store: "Store B",
    orderId: "5746",
    email: "uss735@gmail.com",
    product: "3",
    amount: "600",
    qty: "4",
    time: "2:30 PM"
  }
];

const columns = [
  {
    flex: 0.25,
    field: "plateform",
    minWidth: 150,
    headerName: "PLATFORM",
    renderCell: ({ row }) => {
      return (
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="subtitle2" sx={{ color: "text.primary" }}>
              {row.plateform}
            </Typography>
          </Box>
        </Box>
      );
    }
  },
  {
    flex: 0.3,
    minWidth: 140,
    field: "store",
    headerName: "STORE",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.store}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 100,
    field: "orderId",
    headerName: "ORDER ID",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.orderId}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 100,
    field: "email",
    headerName: "EMAIL",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.email}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "product",
    headerName: "PRODUCT",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.product}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "amount",
    headerName: "AMOUNT",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.amount}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "qty",
    headerName: "QTY",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.qty}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "time",
    headerName: "TIME",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.time}</Typography>
    )
  },
  {
    flex: 0.15,
    minWidth: 110,
    field: "status",
    headerName: "STATUS",
    renderCell: ({ row }) => (
      <CustomChip
        skin="light"
        size="small"
        label={row.status}
        color={statusObj[row.status].color}
        sx={{
          textTransform: "capitalize",
          "& .MuiChip-label": { px: 2.5, lineHeight: 1.385 }
        }}
      />
    )
  }
];
const EcommerceTable = () => {
  return (
    <><CardHeader sx={{ padding:0,paddingLeft: 45,paddingBottom:2, boxShadow: 'rgba(76, 78, 100, 0.22) 0px 2px 10px 0px'}} title="Latest Transactions" />
    <Card sx={{ borderRadius: 3}}>
      <StyledDataGrid
        autoHeight
        hideFooter
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        pagination={undefined}
      />
    </Card>
    </>
  );
};

export default EcommerceTable;
