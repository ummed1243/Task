/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 09/04/2024 - 18:37:00
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 09/04/2024
    * - Author          : admin
    * - Modification    : 
**/
// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Divider from '@mui/material/Divider'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'
import CircularProgress from '@mui/material/CircularProgress'

// ** Icon Imports
import Icon from '../../../../@core/components/icon'

const EcommerceImpressionsOrders = () => {
  return (
    <Card>
      <CardContent sx={{ py: theme => `${theme.spacing(0.625)} !important` }}>
        <Box sx={{ my: 1.375, display: 'flex', alignItems: 'center' }}>
          <Box sx={{ mr: 6.5, display: 'flex', position: 'relative' }}>
            <CircularProgress
              size={60}
              value={100}
              thickness={5}
              variant='determinate'
              sx={{
                position: 'absolute',
                color: '#f2f2f4',
                '& .MuiCircularProgress-circle': { strokeWidth: 4 }
              }}
            />
            <CircularProgress
              size={60}
              value={84}
              thickness={5}
              color='primary'
              variant='determinate'
              sx={{ '& .MuiCircularProgress-circle': { strokeWidth: 4, strokeLinecap: 'round' } }}
            />
          </Box>
          <div>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center' }}>
              <Typography variant='h6' sx={{ mr: 1.75 }}>
                $84
              </Typography>
            </Box>
            <Typography variant='body2'>On Hold</Typography>
          </div>
        </Box>
      </CardContent>
      <Divider sx={{ my: '0 !important' }} />
      <CardContent sx={{ py: theme => `${theme.spacing(0.625)} !important` }}>
        <Box sx={{ my: 1.375, display: 'flex', alignItems: 'center' }}>
          <Box sx={{ mr: 6.5, position: 'relative' }}>
            <CircularProgress
              size={60}
              value={100}
              thickness={5}
              variant='determinate'
              sx={{
                position: 'absolute',
                color: '#f2f2f4',
                '& .MuiCircularProgress-circle': { strokeWidth: 4 }
              }}
            />
            <CircularProgress
              size={60}
              thickness={5}
              value={40}
              color='warning'
              variant='determinate'
              sx={{ '& .MuiCircularProgress-circle': { strokeWidth: 4, strokeLinecap: 'round' } }}
            />
          </Box>
          <div>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center' }}>
              <Typography variant='h6' sx={{ mr: 1.75 }}>
                $40
              </Typography>
            </Box>
            <Typography variant='body2'>Pending</Typography>
          </div>
        </Box>
      </CardContent>
    </Card>
  )
}

export default EcommerceImpressionsOrders
