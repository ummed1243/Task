/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 10/04/2024 - 14:42:33
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 10/04/2024
 * - Author          : admin
 * - Modification    :
 **/
// ** MUI Imports
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { DataGrid } from "@mui/x-data-grid";
import CardHeader from "@mui/material/CardHeader";
// ** Custom Components
import CustomChip from "../../../../@core/components/mui/chip";
import { styled } from '@mui/material/styles';

const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-columnHeader': {
    backgroundColor: '#f5f5f7' // Set your desired background color here
  }
}));
const rows = [
  {
    id: 1,
    amount: "$200",
    transaction: "50",
    name: "Jordan Stevenson",
    username: "@jstevenson5c",
    email: "susanna.Lind57@gmail.com",
    avatarSrc: "/images/avatars/1.png"
  },
  {
    id: 2,
    amount: "$300",
    transaction: "10",
    name: "Robert Crawford",
    username: "@rcrawford1d",
    avatarSrc: "/images/avatars/3.png",
    email: "susanna.Lind57@gmail.com"
  },
  {
    id: 3,
    amount: "$850",
    transaction: "4",
    name: "Lydia Reese",
    username: "@lreese3b",
    email: "milo86@hotmail.com",
    avatarSrc: "/images/avatars/2.png"
  },
  {
    id: 4,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },
  {
    id: 5,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },
  {
    id: 6,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },
  {
    id: 7,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },{
    id: 8,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },{
    id: 9,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  },{
    id: 10,
    amount: "$420",
    transaction: "30",
    name: "Richard Sims",
    username: "@rsims6f",
    email: "lonnie35@hotmail.com",
    avatarSrc: "/images/avatars/5.png"
  }
];

const columns = [
  {
    flex: 0.3,
    minWidth: 200,
    field: "email",
    headerName: "Email",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.email}</Typography>
    )
  },
  {
    flex: 0.3,
    minWidth: 100,
    field: "amount",
    headerName: "Amount",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.amount}</Typography>
    )
  },
  {
    flex: 0.3,
    minWidth: 100,
    field: "transaction",
    headerName: "TX NO.",
    renderCell: ({ row }) => (
      <CustomChip
        skin="light"
        size="small"
        label={row.transaction}
        color={'warning'}
        sx={{
          textTransform: "capitalize",
          "& .MuiChip-label": { px: 2.5, lineHeight: 1.385 }
        }}
      />
    )
  }
];

const TopCustomerTable = () => {
  return (
    <>
    <CardHeader sx={{ padding:0,paddingLeft: 18,paddingBottom:0.25, boxShadow: 'rgba(76, 78, 100, 0.22) 0px 2px 10px 0px'}} title="Top 10 Customer" />
    <Card sx={{ padding: 0, borderRadius: 3 }}>
    <Box sx={{ maxHeight: 364, overflowY: 'auto' }}>
      <StyledDataGrid
        autoHeight
        hideFooter
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        pagination={undefined}
      />
    </Box>
</Card>

    </>
  );
};

export default TopCustomerTable;
