/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 09/04/2024 - 18:43:50
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 09/04/2024
 * - Author          : admin
 * - Modification    :
 **/
// ** MUI Imports
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { DataGrid } from "@mui/x-data-grid";
import { styled } from '@mui/material/styles';

const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-columnHeader': {
    backgroundColor: '#f5f5f7' // Set your desired background color here
  }
}));
const rows = [
  {
    id: 1,
    altmsg: "",
    time: ""
  },
  {
    id: 2,
    altmsg: "",
    time: ""
  }
];

const columns = [
  {
    flex: 0.25,
    field: "plateform",
    minWidth: 150,
    headerName: "ALERT MSSG",
    renderCell: ({ row }) => {
      return (
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="subtitle2" sx={{ color: "text.primary" }}>
              {row.plateform}
            </Typography>
          </Box>
        </Box>
      );
    }
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "time",
    headerName: "TIME",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.time}</Typography>
    )
  }
];
const EcommerceActivityTimeline = () => {
  return (
    <>
    <Card sx={{ borderRadius: 3, boxShadow: 'rgba(76, 78, 100, 0.22) 0px 2px 10px 0px'}}>
    <StyledDataGrid
        autoHeight
        hideFooter
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        pagination={undefined}
      />

      {/* <DataGrid
        autoHeight
        hideFooter
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        pagination={undefined}
        classes={{
          columnBuffer: classes.columnBuffer // Apply custom styles to the column buffer
        }}
      /> */}
    </Card>
    </>
  );
};

export default EcommerceActivityTimeline;
