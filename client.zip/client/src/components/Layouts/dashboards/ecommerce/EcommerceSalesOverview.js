/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 09/04/2024 - 18:39:59
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 09/04/2024
    * - Author          : admin
    * - Modification    : 
**/
// ** MUI Imports
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'

// ** Icon Imports
import Icon from '../../../../@core/components/icon'

// ** Custom Components Imports
import CustomAvatar from '../../../../@core/components/mui/avatar'
import OptionsMenu from '../../../../@core/components/option-menu'

const salesData = [
  {
    stats: '8,458',
    color: 'primary',
    title: 'Customers',
    icon: <Icon icon='mdi:account-outline' />
  },
  {
    stats: '$28.5',
    color: 'warning',
    title: 'Total Amount',
    icon: <Icon icon='mdi:poll' />
  },
  {
    color: 'info',
    stats: '$2,450',
    title: 'Transactions',
    icon: <Icon icon='mdi:trending-up' />
  },
  {
    color: 'info',
    stats: '$2,450',
    title: 'Refund',
    icon: <Icon icon='mdi:trending-up' />
  },
  {
    color: 'info',
    stats: '$2,450',
    title: 'Fraud',
    icon: <Icon icon='mdi:trending-up' />
  }
]

const renderStats = () => {
  return salesData.map((sale, index) => (
    <Grid item xs={12} sm={2.4} key={index}>
      <Box key={index} sx={{ display: 'flex', alignItems: 'center' }}>
        <CustomAvatar skin='light' variant='rounded' color={sale.color} sx={{ mr: 1 }}>
          {sale.icon}
        </CustomAvatar>
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <Typography variant='h7' sx={{ fontWeight: 600 }}>
            {sale.stats}
          </Typography>
          <Typography variant='caption'>{sale.title}</Typography>
        </Box>
      </Box>
    </Grid>
  ))
}

const EcommerceSalesOverview = () => {
  return (
    <Card sx={{ borderRadius: 3, boxShadow: 'rgba(76, 78, 100, 0.22) 0px 2px 10px 0px'}}>
      <CardHeader
        sx={{ pb: 3.25 }}
        title='Daily Sales Overview'
        titleTypographyProps={{ variant: 'h6' }}
        subheader={
          <Box sx={{ display: 'flex', alignItems: 'center', '& svg': { color: 'success.main' } }}>
            <Typography variant='caption' sx={{ mr: 1.5 }}>
              All Stores
            </Typography>
          </Box>
        }
      />
      <CardContent>
        <Grid container spacing={2}>
          {renderStats()}
        </Grid>
      </CardContent>
    </Card>
  )
}

export default EcommerceSalesOverview
