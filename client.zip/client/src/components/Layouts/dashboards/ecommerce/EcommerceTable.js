/**
 * @description      :
 * @author           : admin
 * @group            :
 * @created          : 09/04/2024 - 18:43:50
 *
 * MODIFICATION LOG
 * - Version         : 1.0.0
 * - Date            : 09/04/2024
 * - Author          : admin
 * - Modification    :
 **/
// ** MUI Imports
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { DataGrid } from "@mui/x-data-grid";
import CardHeader from '@mui/material/CardHeader'
// ** Icon Imports
import Icon from "../../../../@core/components/icon";

// ** Custom Components
import CustomChip from "../../../../@core/components/mui/chip";
import CustomAvatar from "../../../../@core/components/mui/avatar";

// ** Utils Import
import { getInitials } from "../../../../@core/utils/get-initials";

const statusObj = {
  complete: { color: "success" },
  pending: { color: "warning" },
  failed: { color: "secondary" }
};

const rows = [
  {
    id: 1,
    role: "admin",
    status: "complete",
    name: "Store A",
    today: "100",
    yesterday: "150",
    month: "150",
    lmonth: "584",
    year: "784",
    lyear: "685"
  },
  {
    id: 2,
    role: "editor",
    status: "complete",
    name: "Store B",
    today: "200",
    yesterday: "160",
    month: "800",
    lmonth: "900",
    year: "1250",
    lyear: "6842"
  },
  {
    id: 3,
    role: "author",
    status: "failed",
    name: "Store C",
    today: "250",
    yesterday: "160",
    month: "780",
    lmonth: "600",
    year: "8758",
    lyear: "69871"
  },
  {
    id: 4,
    role: "editor",
    status: "pending",
    name: "Store D",
    today: "54",
    yesterday: "650",
    month: "400",
    lmonth: "620",
    year: "3514",
    lyear: "12500"
  }
];

const renderUserAvatar = (row) => {
  if (row?.avatarSrc) {
    return (
      <CustomAvatar
        src={row?.avatarSrc}
        sx={{ mr: 3, width: 34, height: 34 }}
      />
    );
  } else {
    return (
      <CustomAvatar
        skin="light"
        sx={{ mr: 3, width: 34, height: 34, fontSize: ".8rem" }}
      >
        {getInitials(row.name ? row.name : "John Doe")}
      </CustomAvatar>
    );
  }
};

const columns = [
  {
    flex: 0.25,
    field: "name",
    minWidth: 150,
    headerName: "Store",
    renderCell: ({ row }) => {
      return (
        <Box sx={{ display: "flex", alignItems: "center" }}>
          {/* {renderUserAvatar(row)} */}
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="subtitle2" sx={{ color: "text.primary" }}>
              {row.name}
            </Typography>
          </Box>
        </Box>
      );
    }
  },
  {
    flex: 0.3,
    minWidth: 140,
    field: "today",
    headerName: "Today",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.today}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 100,
    field: "yesterday",
    headerName: "Yesterday",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.yesterday}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "month",
    headerName: "This Month",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.month}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "lmonth",
    headerName: "Last Month",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.lmonth}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "year",
    headerName: "This Year",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.year}</Typography>
    )
  },
  {
    flex: 0.2,
    minWidth: 90,
    field: "lyear",
    headerName: "Last Year",
    renderCell: ({ row }) => (
      <Typography variant="body2">{row.lyear}</Typography>
    )
  }
];
const EcommerceTable = () => {
  return (
    <Card>
      <CardHeader
        sx={{ pb: 3.25 }}
        title='Amount/Tx.No/Refund/Fraud'
        titleTypographyProps={{ variant: 'h6' }}
      />

      <DataGrid
        autoHeight
        hideFooter
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        pagination={undefined}
      />
    </Card>
  );
};

export default EcommerceTable;
