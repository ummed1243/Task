/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 09/04/2024 - 18:40:36
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 09/04/2024
    * - Author          : admin
    * - Modification    : 
**/
// ** React Imports
import { useState } from 'react'

// ** MUI Import
import Box from '@mui/material/Box'
import Tab from '@mui/material/Tab'
import Card from '@mui/material/Card'
import TabList from '@mui/lab/TabList'
import Table from '@mui/material/Table'
import TabPanel from '@mui/lab/TabPanel'
import Avatar from '@mui/material/Avatar'
import TabContext from '@mui/lab/TabContext'
import TableRow from '@mui/material/TableRow'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableHead from '@mui/material/TableHead'
import CardHeader from '@mui/material/CardHeader'
import Typography from '@mui/material/Typography'
import TableContainer from '@mui/material/TableContainer'

// ** Icon Imports
import Icon from '../../../../@core/components/icon'

// ** Custom Components
import CustomChip from '../../../../@core/components/mui/chip'
import OptionsMenu from '../../../../@core/components/option-menu'

// ** Util Import
import { hexToRGBA } from '../../../../@core/utils/hex-to-rgba'

const statusObj = {
  'in-stock': { text: 'In Stock', color: 'success' },
  'coming-soon': { text: 'Coming Soon', color: 'warning' },
  'out-of-stock': { text: 'Out of Stock', color: 'primary' }
}

const tabAvatars = [
  {
    imgWidth: 30,
    imgHeight: 58,
    category: 'mobile'
  },
  {
    imgWidth: 52,
    imgHeight: 42,
    category: 'desktop'
  },
  {
    imgWidth: 60,
    imgHeight: 42,
    category: 'console'
  }
]

const tabContentData = {
  mobile: [
    {
      amount: '$12.5k',
      qty: '24',
      imgAlt: 'samsung-s22',
      product: 'Samsung s22',
      imgSrc: '/images/cards/samsung-s22.png'
    },
    {
      amount: '$45k',
      qty: '50',
      imgAlt: 'apple-iPhone-13-pro',
      product: 'Apple iPhone 13 Pro',
      imgSrc: '/images/cards/apple-iPhone-13-pro.png'
    },
    {
      amount: '$98.2k',
      qty: '55',
      imgAlt: 'oneplus-9-pro',
      product: 'Oneplus 9 Pro',
      imgSrc: '/images/cards/oneplus-9-pro.png'
    }
  ],
  desktop: [
    {
      amount: '$94.6k',
      qty: '16',
      imgAlt: 'apple-mac-mini',
      product: 'Apple Mac Mini',
      imgSrc: '/images/cards/apple-mac-mini.png'
    },
    {
      amount: '$76.5k',
      qty: '27',
      imgAlt: 'hp-envy-x360',
      product: 'Newest HP Envy x360',
      imgSrc: '/images/cards/hp-envy-x360.png'
    },
    {
      amount: '$69.3k',
      qty: '9',
      imgAlt: 'dell-inspiron-3000',
      product: 'Dell Inspiron 3000',
      imgSrc: '/images/cards/dell-inspiron-3000.png'
    }
  ],
  console: [
    {
      amount: '$18.6k',
      qty: '34',
      imgAlt: 'sony-play-station-5',
      product: 'Sony Play Station 5',
      imgSrc: '/images/cards/sony-play-station-5.png'
    },
    {
      amount: '$29.7k',
      qty: '21',
      imgAlt: 'xbox-series-x',
      product: 'XBOX Series X',
      imgSrc: '/images/cards/xbox-series-x.png'
    },
    {
      amount: '$10.4k',
      qty: '38',
      imgAlt: 'nintendo-switch',
      product: 'Nintendo Switch',
      imgSrc: '/images/cards/nintendo-switch.png'
    }
  ]
}

const RenderTabContent = ({ data }) => {
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow sx={{ '& .MuiTableCell-root': { py: theme => `${theme.spacing(2.5)} !important` } }}>
            <TableCell>Image</TableCell>
            <TableCell sx={{ whiteSpace: 'nowrap' }}>Product Name</TableCell>
            <TableCell align='right'>Amount</TableCell>
            <TableCell align='right'>Qty</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row, index) => (
            <TableRow
              key={index}
              sx={{
                '& .MuiTableCell-root': {
                  border: 0,
                  py: theme => `${theme.spacing(1.5)} !important`
                },
                '&:first-child .MuiTableCell-body': {
                  pt: theme => `${theme.spacing(3)} !important`
                },
                '&:last-child .MuiTableCell-body': {
                  pb: theme => `${theme.spacing(3)} !important`
                }
              }}
            >
              <TableCell>
                <Avatar alt={row.imgAlt} src={row.imgSrc} variant='rounded' sx={{ width: 34, height: 34 }} />
              </TableCell>
              <TableCell>
                <Typography variant='body2' sx={{ fontWeight: 600, whiteSpace: 'nowrap', color: 'text.primary' }}>
                  {row.product}
                </Typography>
              </TableCell>
              <TableCell align='right'>
              <Typography
                  variant='body2'
                  sx={{ fontWeight: 600, textAlign: 'right', whiteSpace: 'nowrap', color: 'text.primary' }}
                >
                  {row.amount}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant='body2'
                  sx={{ fontWeight: 600, textAlign: 'right', whiteSpace: 'nowrap', color: 'text.primary' }}
                >
                  {row.qty}
                </Typography>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  )
}

const EcommerceSalesOverviewWithTabs = () => {
  // ** State
  const [value, setValue] = useState('mobile')

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  const RenderTabAvatar = ({ data }) => (
    <Avatar
      variant='rounded'
      alt={`tabs-${data.category}`}
      src={`/images/cards/tabs-${data.category}.png`}
      sx={{
        width: 100,
        height: 92,
        backgroundColor: 'transparent',
        '& img': { width: data.imgWidth, height: data.imgHeight },
        border: theme =>
          value === data.category ? `2px solid ${theme.palette.primary.main}` : `2px dashed ${theme.palette.divider}`
      }}
    />
  )

  return (
    <Card>
      <CardHeader
        title='Top 5 Selling Products'
        // subheader='82% Activity Growth'
        action={
          <OptionsMenu
            options={['Last 28 Days', 'Last Month', 'Last Year']}
            iconButtonProps={{ size: 'small', className: 'card-more-options' }}
          />
        }
      />
      <TabContext value={value}>
        <TabList
          variant='scrollable'
          scrollButtons='auto'
          onChange={handleChange}
          aria-label='top referral sources tabs'
          sx={{
            mb: 2.5,
            px: 5,
            '& .MuiTab-root:not(:last-child)': { mr: 4 },
            '& .MuiTabs-indicator': { display: 'none' }
          }}
        >
          <Tab value='mobile' sx={{ p: 0 }} label={<RenderTabAvatar data={tabAvatars[0]} />} />
          <Tab value='desktop' sx={{ p: 0 }} label={<RenderTabAvatar data={tabAvatars[1]} />} />
          <Tab value='console' sx={{ p: 0 }} label={<RenderTabAvatar data={tabAvatars[2]} />} />
          {/* <Tab
            // disabled
            value='add'
            sx={{ p: 0 }}
            label={
              <Avatar
                variant='rounded'
                sx={{
                  width: 100,
                  height: 92,
                  backgroundColor: 'transparent',
                  border: theme =>
                    value === 'add' ? `2px solid ${theme.palette.primary.main}` : `2px dashed ${theme.palette.divider}`
                }}
              >
                <Box
                  sx={{
                    width: 30,
                    height: 30,
                    display: 'flex',
                    borderRadius: '8px',
                    alignItems: 'center',
                    color: 'action.active',
                    justifyContent: 'center',
                    backgroundColor: theme => hexToRGBA(theme.palette.secondary.main, 0.12)
                  }}
                >
                  <Icon icon='mdi:plus' />
                </Box>
              </Avatar>
            }
          /> */}
        </TabList>

        <TabPanel sx={{ p: 0 }} value='mobile'>
          <RenderTabContent data={tabContentData['mobile']} />
        </TabPanel>
        <TabPanel sx={{ p: 0 }} value='desktop'>
          <RenderTabContent data={tabContentData['desktop']} />
        </TabPanel>
        <TabPanel sx={{ p: 0 }} value='console'>
          <RenderTabContent data={tabContentData['console']} />
        </TabPanel>
      </TabContext>
    </Card>
  )
}

export default EcommerceSalesOverviewWithTabs
