/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 10/04/2024 - 17:01:57
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 10/04/2024
    * - Author          : admin
    * - Modification    : 
**/
import logo from '../../../assets/images/logo.png';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';


const Header = () => {

  const { user } = useSelector((state) => state.user);
  return (

    <header className="bg-primary-blue fixed top-0 py-2.4 w-full z-10">
      <div className="w-full sm:w-11/12 px-1 sm:px-4 m-auto flex justify-between items-center relative">
        <div className="flex items-center flex-1">
          <Link className="h-7 mr-1 sm:mr-4" to="/">
            <img draggable="false" className="h-full w-full set-logo-header object-contain" src={logo} alt="Task Logo" />
          </Link>
        </div>
        <div className="flex items-center justify-between ml-1 sm:ml-0 gap-0.5 sm:gap-7 relative">
              <span className="userDropDown flex items-center text-white font-medium gap-1 cursor-pointer" >{user.username && user.username.split(" ", 1)}
              </span>
        </div>
      </div>
    </header>
  )
};

export default Header;
