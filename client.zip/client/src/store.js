/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 08/04/2024 - 14:27:31
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 08/04/2024
    * - Author          : admin
    * - Modification    : 
**/
import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import { userReducer } from './reducers/userReducer';

const reducer = combineReducers({
    user: userReducer,
});


const middleware = [thunk];

const store = createStore(
    reducer,
    composeWithDevTools(applyMiddleware(...middleware))
);

export default store;