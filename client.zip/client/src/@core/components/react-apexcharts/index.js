/**
    * @description      : 
    * @author           : admin
    * @group            : 
    * @created          : 10/04/2024 - 11:09:47
    * 
    * MODIFICATION LOG
    * - Version         : 1.0.0
    * - Date            : 10/04/2024
    * - Author          : admin
    * - Modification    : 
**/
// ** Next Import
import dynamic from 'next/dynamic'

// ! To avoid 'Window is not defined' error
const ReactApexcharts = dynamic(() => import('react-apexcharts'), { ssr: false })

export default ReactApexcharts
